sap.ui.define(["sap/m/MessageToast"],function(a){"use strict";return{CalculateCashflow:function(s,e){a.show("Cashflow calculated")}}});
//# sourceMappingURL=CalculateCashflow.js.map