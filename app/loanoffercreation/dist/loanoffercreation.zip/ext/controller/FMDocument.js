sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{FMDocument:function(n,s){e.show("FM Document")}}});
//# sourceMappingURL=FMDocument.js.map