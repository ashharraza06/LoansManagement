sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(s){e.show("Selected")}}});
//# sourceMappingURL=Pretend.js.map