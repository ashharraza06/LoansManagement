sap.ui.define(['sap/ui/core/mvc/ControllerExtension'], function (ControllerExtension) {
	'use strict';

	return ControllerExtension.extend('loanservicing.loanservicing.ext.controller.Listcontroller', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf loanservicing.loanservicing.ext.controller.Listcontroller
			 */
			onInit: function () {
				// you can access the Fiori elements extensionAPI via this.base.getExtensionAPI
				var oModel = this.base.getExtensionAPI().getModel();
				debugger;

			},
			routing: {
				onAfterBinding: function () {
					debugger
					var presscreate = sap.ui.getCore().getElementById("loanservicing.loanservicing::postingInvoicesList--fe::table::postingInvoices::LineItem::StandardAction::Create").firePress();
					console.log("createpress", presscreate)
				}
			}
		}
	});
});
