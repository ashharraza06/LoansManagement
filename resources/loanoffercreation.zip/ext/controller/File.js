sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{file:function(s,n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=File.js.map