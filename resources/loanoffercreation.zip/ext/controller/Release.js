sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Release:function(s,a){e.show("Released")}}});
//# sourceMappingURL=Release.js.map