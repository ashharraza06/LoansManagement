sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Releasedisbursement:function(s,n){e.show("Released")}}});
//# sourceMappingURL=Releasedisbursement.js.map